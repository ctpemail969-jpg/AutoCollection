package com.example.autocollection;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int PICK_CSV = 10, PICK_AUDIO = 11;
    private final ArrayList<String> numbers = new ArrayList<>();
    private final ArrayList<String> logs = new ArrayList<>();
    private final Set<String> excluded = new HashSet<>();
    private SharedPreferences prefs;
    private LinearLayout listBox;
    private TextView countText, audioText, statusText;
    private EditText intervalInput;
    private Uri audioUri;
    private int nextIndex = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("campaign", MODE_PRIVATE);
        if (prefs.contains("audio")) audioUri = Uri.parse(prefs.getString("audio", ""));
        excluded.addAll(prefs.getStringSet("excluded", new HashSet<>()));
        buildUi(); refresh();
    }
    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(0xff172033); t.setPadding(8, 10, 8, 10); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(v -> action.run()); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("الاتصال الآلي للتحصيل", 24); title.setGravity(Gravity.CENTER); root.addView(title);
        root.addView(text("نسخة أولية لإدارة العملاء والمتابعة اليدوية", 14));
        countText = text("عدد العملاء: 0",18); root.addView(countText);
        root.addView(button("استيراد قائمة CSV", () -> pick(PICK_CSV, "text/*")));
        root.addView(button("اختيار التسجيل الصوتي", () -> pick(PICK_AUDIO, "audio/*")));
        audioText = text("لم يتم اختيار تسجيل صوتي",14); root.addView(audioText);
        root.addView(text("الفاصل بين المتابعات (ثانية)",16));
        intervalInput = new EditText(this); intervalInput.setInputType(2);
        intervalInput.setText(prefs.getString("interval", "30")); intervalInput.setSingleLine(true); root.addView(intervalInput);
        root.addView(button("حفظ الإعدادات", () -> {
            try { int seconds = Integer.parseInt(intervalInput.getText().toString().trim());
                if (seconds < 1) throw new NumberFormatException();
                prefs.edit().putString("interval", String.valueOf(seconds)).apply();
                Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this,"اكتب مدة صحيحة أكبر من صفر",Toast.LENGTH_SHORT).show(); }
        }));
        root.addView(button("الاتصال بالعميل التالي (يدويًا)", this::dialNext));
        root.addView(button("إعادة المؤشر لأول القائمة", () -> { nextIndex=0; statusText.setText("تمت إعادة المؤشر."); }));
        root.addView(button("إدارة قائمة عدم الاتصال", this::manageExclusions));
        statusText = text("جاهز",14); root.addView(statusText);
        root.addView(text("قائمة العملاء",20)); listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL); root.addView(listBox);
        root.addView(text("سجل النشاط",20));
    }
    private void pick(int code, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type);
        startActivityForResult(i,code);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if (requestCode==PICK_AUDIO) {
            audioUri=uri;
            try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            prefs.edit().putString("audio",uri.toString()).apply(); audioText.setText("تم اختيار التسجيل الصوتي");
        } else if (requestCode==PICK_CSV) importCsv(uri);
    }
    private void importCsv(Uri uri) {
        int added=0;
        try (InputStream in=getContentResolver().openInputStream(uri);
             BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
            String line;
            while ((line=br.readLine())!=null) {
                String[] cells=line.split("[,;\\t]");
                for (String cell:cells) {
                    String n=cell.replaceAll("[^0-9+]", "");
                    if (n.matches("\\+?[0-9]{8,15}") && !numbers.contains(n)) { numbers.add(n); added++; break; }
                }
            }
            nextIndex=0; logs.add("تم استيراد "+added+" رقم."); refresh();
            Toast.makeText(this,"تم استيراد "+added+" رقم",Toast.LENGTH_LONG).show();
        } catch(Exception e) { Toast.makeText(this,"تعذر قراءة الملف. استخدم CSV نصي.",Toast.LENGTH_LONG).show(); }
    }
    private void dialNext() {
        while(nextIndex<numbers.size() && excluded.contains(numbers.get(nextIndex))) nextIndex++;
        if(nextIndex>=numbers.size()) { statusText.setText("انتهت القائمة أو لا توجد أرقام متاحة."); return; }
        String number=numbers.get(nextIndex++); logs.add("تم فتح شاشة الاتصال للرقم "+number);
        statusText.setText("راجع الرقم ثم اضغط اتصال بنفسك: "+number); refresh();
        startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number))));
    }
    private void manageExclusions() {
        if(numbers.isEmpty()) { Toast.makeText(this,"استورد قائمة أرقام أولًا",Toast.LENGTH_SHORT).show(); return; }
        String[] items=numbers.toArray(new String[0]); boolean[] checked=new boolean[items.length];
        for(int i=0;i<items.length;i++) checked[i]=excluded.contains(items[i]);
        new AlertDialog.Builder(this).setTitle("حدد الأرقام المستبعدة")
            .setMultiChoiceItems(items,checked,(d,w,on)->{ if(on) excluded.add(items[w]); else excluded.remove(items[w]); })
            .setPositiveButton("حفظ",(d,w)->{ prefs.edit().putStringSet("excluded",new HashSet<>(excluded)).apply(); refresh(); })
            .setNegativeButton("إلغاء",null).show();
    }
    private void refresh() {
        if(countText==null) return;
        countText.setText("عدد العملاء: "+numbers.size()+" | مستبعد: "+excluded.size());
        if(audioUri!=null) audioText.setText("تم اختيار تسجيل صوتي");
        listBox.removeAllViews(); int shown=Math.min(numbers.size(),100);
        for(int i=0;i<shown;i++) { String n=numbers.get(i); listBox.addView(text((excluded.contains(n)?"⛔ ":"• ")+n,15)); }
        if(numbers.size()>shown) listBox.addView(text("يتم عرض أول 100 رقم فقط.",12));
        for(int i=Math.max(0,logs.size()-20);i<logs.size();i++) listBox.addView(text(logs.get(i),12));
    }
}
